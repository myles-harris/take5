const Cadence = Object.freeze({
    DAILY: 'daily',
    WEEKLY: 'weekly',
    MONTHLY: 'monthly'
});

export { Cadence }; 